<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Karyawan</title>
    <link rel="stylesheet" href="home.css">
</head>

<body>
    <h1>Daftar Karyawan</h1>
    <br><br><br><br>
    <a href='add.php'>Tambah Karyawan</a><br><br>
    <table border='1'>
    <tr>   <th>Nama</th> <th>Umur</th> <th>Alamat</th> <th>Nomor Telepon</th> <th>Pilih</th>   </tr>

<?php
$file = 'data.json';
$data = json_decode(file_get_contents($file), true) ?? [];

foreach ($data as $key => $x) {
    // Data = data karyawan
    // Key = id dari datanya
    // x = valuenya
    echo "<tr>
        <td>{$x['nama']}</td>
        <td>{$x['umur']}</td>
        <td>{$x['alamat']}</td>
        <td>{$x['telepon']}</td>
        <td> <a href='edit.php?id=$key'>Edit</a> | <a href='delete.php?id=$key'>Hapus</a> </td>
    </tr>";
}

?>

</body>


